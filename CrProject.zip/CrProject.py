
"""
NCRB 2021 CRIME MOTIVE ANALYTICS
BTech CSE / Data Science Final-Year Project
Python 3.13 | Anaconda Spyder | Windows

Dataset folder:
C:\\Users\\Lenovo\\Downloads

Outputs:
NCRB_Professional_Project_Output
"""

import os
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import LeaveOneOut, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    ConfusionMatrixDisplay,
    silhouette_score
)

warnings.filterwarnings("ignore")

sns.set_theme(style="whitegrid", context="notebook")
plt.ioff()

plt.rcParams.update({
    "figure.facecolor": "#F5F7FB",
    "axes.facecolor": "white",
    "axes.titleweight": "bold",
    "axes.titlesize": 11,
    "axes.labelsize": 9,
    "font.size": 9,
    "savefig.facecolor": "#F5F7FB"
})


# ==================================================
# MAIN FUNCTION
# ==================================================

def main():

    # ==================================================
    # 1. AUTOMATIC DATASET LOADING
    # ==================================================

    print("\nLoading NCRB 2021 Dataset...")

    download_folder = r"C:\Users\Lenovo\Downloads"

    if not os.path.isdir(download_folder):
        raise FileNotFoundError(
            "Downloads folder not found: " + download_folder
        )

    csv_files = sorted([
        os.path.join(download_folder, f)
        for f in os.listdir(download_folder)
        if f.lower().endswith(".csv")
    ])

    if not csv_files:
        raise FileNotFoundError(
            "No CSV dataset found in Downloads."
        )

    if len(csv_files) > 1:

        matching = [
            f for f in csv_files
            if "ncrb" in os.path.basename(f).lower()
            or "crime" in os.path.basename(f).lower()
        ]

        if len(matching) == 1:
            file_path = matching[0]
        else:
            raise ValueError(
                "Multiple CSV files found. Please keep only "
                "the NCRB dataset in Downloads, or edit the "
                "file selection logic."
            )

    else:
        file_path = csv_files[0]

    print("Dataset:", file_path)

    out_dir = os.path.join(
        download_folder,
        "NCRB_Professional_Project_Output"
    )

    os.makedirs(out_dir, exist_ok=True)

    raw = pd.read_csv(
        file_path,
        encoding="utf-8-sig"
    )

    raw.columns = raw.columns.astype(str).str.strip()

    required = {"State/UT", "Total"}

    if not required.issubset(raw.columns):
        raise ValueError(
            "Dataset must contain State/UT and Total columns."
        )

    data = raw.copy()

    data["State/UT"] = data["State/UT"].astype(str).str.strip()

    data = data[
        ~data["State/UT"].str.lower().str.startswith("total")
    ].copy()

    numeric_cols = [
        c for c in data.columns
        if c not in {"Sl. No.", "State/UT"}
    ]

    for col in numeric_cols:
        data[col] = pd.to_numeric(
            data[col].astype(str).str.replace(",", "", regex=False),
            errors="coerce"
        )

    data[numeric_cols] = data[numeric_cols].fillna(0)

    motive_cols = [
        c for c in numeric_cols if c != "Total"
    ]

    if len(data) < 4 or len(motive_cols) < 2:
        raise ValueError(
            "Insufficient dataset rows or motive columns."
        )

    if (data[numeric_cols] < 0).any().any():
        raise ValueError(
            "Negative values found in numeric columns."
        )

    data = data.reset_index(drop=True)

    data["Motive Sum"] = data[motive_cols].sum(axis=1)

    mismatches = data.loc[
        ~np.isclose(data["Motive Sum"], data["Total"]),
        ["State/UT", "Total", "Motive Sum"]
    ]

    if not mismatches.empty:
        mismatches.to_csv(
            os.path.join(out_dir, "data_quality_total_mismatches.csv"),
            index=False
        )

    total_cases = data["Total"].sum()

    if total_cases <= 0:
        raise ValueError("Total recorded cases must be positive.")

    motive_totals = data[motive_cols].sum().sort_values(
        ascending=False
    )

    motive_table = motive_totals.rename(
        "Cases"
    ).reset_index()

    motive_table.columns = ["Motive", "Cases"]

    motive_table["Share_pct"] = (
        100 * motive_table["Cases"] / total_cases
    )

    state_table = data[
        ["State/UT", "Total"]
    ].sort_values(
        "Total", ascending=False
    ).reset_index(drop=True)

    state_table["Rank"] = np.arange(
        1, len(state_table) + 1
    )

    state_table["Share_pct"] = (
        100 * state_table["Total"] / total_cases
    )

    motive_table.to_csv(
        os.path.join(out_dir, "01_motive_summary.csv"),
        index=False
    )

    state_table.to_csv(
        os.path.join(out_dir, "02_state_ranking.csv"),
        index=False
    )

    data.drop(columns=["Motive Sum"]).to_csv(
        os.path.join(out_dir, "cleaned_dataset.csv"),
        index=False
    )

    print("\nDATASET SUMMARY")
    print("-" * 50)
    print("Regions:", len(data))
    print("Motive categories:", len(motive_cols))
    print("Total cases:", f"{total_cases:,.0f}")

    print("\nTOP FIVE MOTIVES")
    print(motive_table.head().to_string(index=False))

    print("\nTOP FIVE REGIONS")
    print(state_table.head().to_string(index=False))

    # ==================================================
    # 2. MOTIVE DISTRIBUTION
    # ==================================================

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    top_motives = motive_table.head(10).sort_values("Cases")

    axes[0].barh(
        top_motives["Motive"],
        top_motives["Cases"],
        color=sns.color_palette("viridis", len(top_motives))
    )

    axes[0].set_title("Top 10 Recorded Crime Motives")
    axes[0].set_xlabel("Recorded Cases")

    leading = motive_table.head(6)

    remainder = max(
        0, total_cases - leading["Cases"].sum()
    )

    labels = leading["Motive"].tolist()
    values = leading["Cases"].tolist()

    if remainder > 0:
        labels.append("Other Motives")
        values.append(remainder)

    axes[1].pie(
        values,
        labels=labels,
        autopct="%1.1f%%",
        startangle=90,
        wedgeprops={"width": 0.42},
        textprops={"fontsize": 8}
    )

    axes[1].set_title("Crime Motive Distribution")

    fig.suptitle(
        "Analysis 1 | National Motive Distribution",
        fontsize=15,
        fontweight="bold"
    )

    fig.savefig(
        os.path.join(out_dir, "analysis_01_motive_distribution.png"),
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 3. STATE / UT COMPARISON
    # ==================================================

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    top_states = state_table.head(12).sort_values("Total")

    axes[0].barh(
        top_states["State/UT"],
        top_states["Total"],
        color="#276FBF"
    )

    axes[0].set_title("Top 12 States/UTs")
    axes[0].set_xlabel("Recorded Cases")

    ordered = state_table.head(15).sort_values("Total")

    axes[1].hlines(
        ordered["State/UT"],
        0,
        ordered["Total"],
        color="#A6B8D4",
        linewidth=2
    )

    axes[1].scatter(
        ordered["Total"],
        ordered["State/UT"],
        s=45,
        color="#E76F51"
    )

    axes[1].set_title("Regional Comparison: Top 15")
    axes[1].set_xlabel("Recorded Cases")

    fig.suptitle(
        "Analysis 2 | State/UT Comparison",
        fontsize=15,
        fontweight="bold"
    )

    fig.savefig(
        os.path.join(out_dir, "analysis_02_regional_comparison.png"),
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 4. MOTIVE COMPOSITION HEATMAP
    # ==================================================

    top_names = state_table.head(
        min(12, len(state_table))
    )["State/UT"].tolist()

    heat = data.set_index("State/UT").loc[
        top_names, motive_cols
    ]

    composition = (
        heat.div(
            heat.sum(axis=1).replace(0, np.nan),
            axis=0
        ).fillna(0) * 100
    )

    composition.to_csv(
        os.path.join(out_dir, "03_regional_motive_composition_pct.csv")
    )

    fig, ax = plt.subplots(figsize=(16, 7))

    sns.heatmap(
        composition,
        cmap="mako",
        linewidths=0.25,
        ax=ax,
        cbar_kws={"label": "Percentage within region"}
    )

    ax.set_title(
        "Analysis 3 | Regional Motive Composition Heatmap"
    )

    ax.set_xlabel("Motive Categories")
    ax.set_ylabel("State/UT")

    plt.setp(
        ax.get_xticklabels(),
        rotation=55,
        ha="right",
        fontsize=8
    )

    fig.savefig(
        os.path.join(out_dir, "analysis_03_motive_heatmap.png"),
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 5. PARETO ANALYSIS
    # ==================================================

    pareto = state_table.copy()

    pareto["Cumulative_share_pct"] = (
        pareto["Share_pct"].cumsum()
    )

    pareto.to_csv(
        os.path.join(out_dir, "04_pareto_concentration.csv"),
        index=False
    )

    fig, ax = plt.subplots(figsize=(13, 6))

    x = np.arange(len(pareto))

    ax.bar(x, pareto["Total"], color="#4C78A8")

    ax.set_ylabel("Recorded Cases")
    ax.set_xlabel("States/UTs ranked by recorded total")

    ax.set_xticks(x)

    ax.set_xticklabels(
        pareto["State/UT"],
        rotation=65,
        ha="right",
        fontsize=8
    )

    ax2 = ax.twinx()

    ax2.plot(
        x,
        pareto["Cumulative_share_pct"],
        color="#E45756",
        marker="o",
        linewidth=2
    )

    ax2.axhline(80, color="gray", linestyle="--")
    ax2.set_ylabel("Cumulative Share (%)")
    ax2.set_ylim(0, 105)

    ax.set_title("Analysis 4 | Pareto Concentration Analysis")

    fig.savefig(
        os.path.join(out_dir, "analysis_04_pareto.png"),
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 6. RELATIONSHIP AND CORRELATION
    # ==================================================

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))

    candidate_pairs = [
        ("Fraud", "Sexual Exploitation"),
        ("Extortion", "Fraud")
    ]

    available_pairs = [
        pair for pair in candidate_pairs
        if pair[0] in data.columns and pair[1] in data.columns
    ]

    if available_pairs:
        a, b = available_pairs[0]

        sns.regplot(
            data=data,
            x=a,
            y=b,
            ax=axes[0],
            scatter_kws={"s": 45, "alpha": 0.75},
            line_kws={"color": "#E45756"}
        )

        axes[0].set_title(
            f"{a} vs {b}: Descriptive Association"
        )
    else:
        axes[0].text(
            0.1, 0.5,
            "Selected motive columns not found",
            transform=axes[0].transAxes
        )

    correlation_cols = motive_totals.head(10).index.tolist()

    sns.heatmap(
        data[correlation_cols].corr(),
        cmap="coolwarm",
        center=0,
        vmin=-1,
        vmax=1,
        annot=True,
        fmt=".2f",
        annot_kws={"size": 7},
        ax=axes[1]
    )

    axes[1].set_title("Correlation Among Leading Motives")

    fig.suptitle(
        "Analysis 5 | Motive Relationships and Correlation",
        fontsize=15,
        fontweight="bold"
    )

    fig.savefig(
        os.path.join(out_dir, "analysis_05_relationships.png"),
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 7. REGRESSION
    # ==================================================

    X = data[motive_cols].astype(float)
    y_total = data["Total"].astype(float)

    n = len(data)

    model_rows = []

    regression_models = {
        "Linear Regression": LinearRegression(),
        "Random Forest Regressor": RandomForestRegressor(
            n_estimators=250,
            random_state=42
        )
    }

    if n >= 5:

        loo = LeaveOneOut()

        for name, model in regression_models.items():

            try:
                predictions = np.zeros(n)

                for train_idx, test_idx in loo.split(X):

                    model.fit(
                        X.iloc[train_idx],
                        y_total.iloc[train_idx]
                    )

                    predictions[test_idx] = model.predict(
                        X.iloc[test_idx]
                    )

                model_rows.append({
                    "Task": "Regression",
                    "Model": name,
                    "MAE": mean_absolute_error(
                        y_total, predictions
                    ),
                    "RMSE": np.sqrt(
                        mean_squared_error(y_total, predictions)
                    ),
                    "R2": r2_score(y_total, predictions),
                    "Accuracy": np.nan,
                    "Precision": np.nan,
                    "Recall": np.nan,
                    "F1": np.nan
                })

            except Exception as error:
                print("Regression skipped:", name, error)

    # ==================================================
    # 8. CLASSIFICATION
    # ==================================================

    y_class = (
        y_total > y_total.median()
    ).astype(int)

    class_models = {
        "Logistic Regression": make_pipeline(
            StandardScaler(),
            LogisticRegression(
                max_iter=2000,
                class_weight="balanced"
            )
        ),
        "KNN": make_pipeline(
            StandardScaler(),
            KNeighborsClassifier(n_neighbors=3)
        ),
        "Naive Bayes": GaussianNB(),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=3,
            random_state=42
        ),
        "SVM": make_pipeline(
            StandardScaler(),
            SVC(
                kernel="rbf",
                class_weight="balanced"
            )
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=250,
            random_state=42,
            class_weight="balanced"
        )
    }

    min_class_count = y_class.value_counts().min()

    if n >= 8 and y_class.nunique() == 2 and min_class_count >= 2:

        splits = min(5, int(min_class_count))

        cv = StratifiedKFold(
            n_splits=splits,
            shuffle=True,
            random_state=42
        )

        for name, model in class_models.items():

            try:
                predictions = np.zeros(n, dtype=int)

                for train_idx, test_idx in cv.split(X, y_class):

                    model.fit(
                        X.iloc[train_idx],
                        y_class.iloc[train_idx]
                    )

                    predictions[test_idx] = model.predict(
                        X.iloc[test_idx]
                    ).astype(int)

                model_rows.append({
                    "Task": "Classification",
                    "Model": name,
                    "MAE": np.nan,
                    "RMSE": np.nan,
                    "R2": np.nan,
                    "Accuracy": accuracy_score(y_class, predictions),
                    "Precision": precision_score(
                        y_class, predictions, zero_division=0
                    ),
                    "Recall": recall_score(
                        y_class, predictions, zero_division=0
                    ),
                    "F1": f1_score(
                        y_class, predictions, zero_division=0
                    )
                })

            except Exception as error:
                print("Classification skipped:", name, error)

    model_results = pd.DataFrame(model_rows)

    model_results.to_csv(
        os.path.join(out_dir, "06_model_evaluation.csv"),
        index=False
    )

    print("\nMACHINE LEARNING RESULTS")

    if not model_results.empty:
        print(model_results.round(3).to_string(index=False))
    else:
        print("No model results generated.")

    # ==================================================
    # 9. CLASSIFICATION DIAGNOSTICS
    # ==================================================

    if n >= 8 and y_class.nunique() == 2:

        final_clf = RandomForestClassifier(
            n_estimators=250,
            random_state=42,
            class_weight="balanced"
        )

        final_clf.fit(X, y_class)

        final_pred = final_clf.predict(X)

        fig, axes = plt.subplots(1, 2, figsize=(13, 5))

        ConfusionMatrixDisplay(
            confusion_matrix(
                y_class, final_pred, labels=[0, 1]
            ),
            display_labels=[
                "At/below median",
                "Above median"
            ]
        ).plot(
            ax=axes[0],
            colorbar=False,
            values_format="d"
        )

        axes[0].set_title("Training-Set Confusion Matrix")

        importances = pd.Series(
            final_clf.feature_importances_,
            index=motive_cols
        ).sort_values().tail(10)

        axes[1].barh(
            importances.index,
            importances.values,
            color="#59A14F"
        )

        axes[1].set_title("Feature Importance")
        axes[1].set_xlabel("Importance")

        fig.suptitle(
            "Classification Diagnostics: Exploratory Only"
        )

        fig.savefig(
            os.path.join(
                out_dir,
                "model_01_classification_diagnostics.png"
            ),
            dpi=220,
            bbox_inches="tight"
        )

    # ==================================================
    # 10. CLUSTERING AND PCA
    # ==================================================

    scaler = StandardScaler()

    X_scaled = scaler.fit_transform(X)

    cluster_count = min(3, n - 1)

    km = KMeans(
        n_clusters=cluster_count,
        n_init=20,
        random_state=42
    )

    data["KMeans_Cluster"] = km.fit_predict(X_scaled)

    data["Hierarchical_Cluster"] = AgglomerativeClustering(
        n_clusters=cluster_count
    ).fit_predict(X_scaled)

    data[
        [
            "State/UT",
            "Total",
            "KMeans_Cluster",
            "Hierarchical_Cluster"
        ]
    ].to_csv(
        os.path.join(out_dir, "07_clustering_assignments.csv"),
        index=False
    )

    if 1 < data["KMeans_Cluster"].nunique() < n:
        silhouette = silhouette_score(
            X_scaled,
            data["KMeans_Cluster"]
        )
    else:
        silhouette = np.nan

    n_components = min(
        2,
        X_scaled.shape[0],
        X_scaled.shape[1]
    )

    pca2_model = PCA(n_components=n_components)

    pca2 = pca2_model.fit_transform(X_scaled)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    if n_components == 2:

        axes[0].scatter(
            pca2[:, 0],
            pca2[:, 1],
            c=data["KMeans_Cluster"],
            cmap="viridis",
            s=65
        )

        for i, region in enumerate(data["State/UT"]):
            axes[0].annotate(
                region,
                (pca2[i, 0], pca2[i, 1]),
                fontsize=6
            )

        axes[1].scatter(
            pca2[:, 0],
            pca2[:, 1],
            c=data["Hierarchical_Cluster"],
            cmap="plasma",
            s=65
        )

    else:
        axes[0].scatter(
            pca2[:, 0],
            np.zeros(n),
            c=data["KMeans_Cluster"],
            cmap="viridis"
        )

        axes[1].scatter(
            pca2[:, 0],
            np.zeros(n),
            c=data["Hierarchical_Cluster"],
            cmap="plasma"
        )

    axes[0].set_title("K-Means Clustering")
    axes[1].set_title("Hierarchical Clustering")

    for ax in axes:
        ax.set_xlabel("Principal Component 1")
        ax.set_ylabel("Principal Component 2")

    fig.suptitle(
        f"Clustering | K={cluster_count} | Silhouette={silhouette:.3f}"
    )

    fig.savefig(
        os.path.join(out_dir, "model_02_clustering_pca.png"),
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 11. PCA DIMENSIONALITY REDUCTION
    # ==================================================

    pca = PCA()

    pca.fit(X_scaled)

    cumulative = (
        np.cumsum(pca.explained_variance_ratio_) * 100
    )

    fig, ax = plt.subplots(figsize=(9, 5))

    ax.plot(
        np.arange(1, len(cumulative) + 1),
        cumulative,
        marker="o",
        color="#B279A2"
    )

    ax.axhline(90, linestyle="--", color="gray")

    ax.set_xlabel("Number of Principal Components")
    ax.set_ylabel("Cumulative Explained Variance (%)")
    ax.set_title("PCA | Cumulative Explained Variance")
    ax.set_ylim(0, 105)

    fig.savefig(
        os.path.join(out_dir, "model_03_pca_variance.png"),
        dpi=220,
        bbox_inches="tight"
    )

    pd.DataFrame({
        "Component": [
            f"PC{i + 1}"
            for i in range(len(pca.explained_variance_ratio_))
        ],
        "Explained_variance_pct": (
            pca.explained_variance_ratio_ * 100
        ),
        "Cumulative_variance_pct": cumulative
    }).to_csv(
        os.path.join(out_dir, "08_pca_variance.csv"),
        index=False
    )

    # ==================================================
    # 12. ASSOCIATION RULE MINING
    # ==================================================

    binary = (data[motive_cols] > 0).astype(int)

    min_support = 0.15

    min_count = max(
        2,
        int(np.ceil(min_support * len(binary)))
    )

    frequent_items = [
        col for col in motive_cols
        if binary[col].sum() >= min_count
    ]

    rules = []

    for i in range(len(frequent_items)):

        for j in range(i + 1, len(frequent_items)):

            a = frequent_items[i]
            b = frequent_items[j]

            support_ab = (
                (binary[a] == 1) & (binary[b] == 1)
            ).mean()

            if support_ab >= min_support:

                support_a = binary[a].mean()
                support_b = binary[b].mean()

                lift = (
                    support_ab / (support_a * support_b)
                    if support_a and support_b
                    else np.nan
                )

                rules.append({
                    "Antecedent": a,
                    "Consequent": b,
                    "Support": support_ab,
                    "Confidence_A_to_B": support_ab / support_a,
                    "Lift_A_to_B": lift
                })

                rules.append({
                    "Antecedent": b,
                    "Consequent": a,
                    "Support": support_ab,
                    "Confidence_A_to_B": support_ab / support_b,
                    "Lift_A_to_B": lift
                })

    rules_df = pd.DataFrame(
        rules,
        columns=[
            "Antecedent",
            "Consequent",
            "Support",
            "Confidence_A_to_B",
            "Lift_A_to_B"
        ]
    )

    if not rules_df.empty:
        rules_df = rules_df.sort_values(
            ["Lift_A_to_B", "Support"],
            ascending=False
        )

    rules_df.to_csv(
        os.path.join(out_dir, "09_association_rules.csv"),
        index=False
    )

    # ==================================================
    # 13. PROFESSIONAL DASHBOARD
    # ==================================================

    fig = plt.figure(
        figsize=(20, 14),
        facecolor="#F5F7FB"
    )

    gs = fig.add_gridspec(
        3, 3,
        hspace=0.42,
        wspace=0.35
    )

    fig.suptitle(
        "NCRB 2021 | Crime Motive Intelligence Dashboard",
        fontsize=21,
        fontweight="bold",
        x=0.04,
        ha="left",
        y=0.985,
        color="#14213D"
    )

    fig.text(
        0.04,
        0.955,
        "Reported counts by State/UT | One-year aggregated dataset",
        fontsize=10,
        color="#526078"
    )

    kpis = [
        ("RECORDED CASES", f"{total_cases:,.0f}"),
        ("REGIONS ANALYSED", str(len(data))),
        ("MOTIVE CATEGORIES", str(len(motive_cols)))
    ]

    for i, (label, value) in enumerate(kpis):

        axk = fig.add_axes([
            0.04 + i * 0.315,
            0.855,
            0.29,
            0.075
        ])

        axk.set_facecolor("white")

        for spine in axk.spines.values():
            spine.set_edgecolor("#D8DEE9")

        axk.set_xticks([])
        axk.set_yticks([])

        axk.text(
            0.04, 0.68,
            label,
            transform=axk.transAxes,
            fontsize=9,
            color="#526078"
        )

        axk.text(
            0.04, 0.18,
            value,
            transform=axk.transAxes,
            fontsize=20,
            fontweight="bold",
            color="#14213D"
        )

    ax = fig.add_subplot(gs[0, 0])

    m = motive_table.head(7).sort_values("Cases")

    ax.barh(
        m["Motive"],
        m["Cases"],
        color="#4C78A8"
    )

    ax.set_title("Leading Motives")
    ax.tick_params(axis="y", labelsize=7)

    ax = fig.add_subplot(gs[0, 1])

    st = state_table.head(8).sort_values("Total")

    ax.barh(
        st["State/UT"],
        st["Total"],
        color="#F28E2B"
    )

    ax.set_title("Highest-Count Regions")
    ax.tick_params(axis="y", labelsize=7)

    ax = fig.add_subplot(gs[0, 2])

    top_five = motive_table.head(5)

    ax.pie(
        top_five["Cases"],
        labels=top_five["Motive"],
        autopct="%1.0f%%",
        startangle=90,
        textprops={"fontsize": 7}
    )

    ax.set_title("Top Five Motives")

    ax = fig.add_subplot(gs[1, 0:2])

    sns.heatmap(
        composition.iloc[:, :min(12, len(motive_cols))],
        cmap="mako",
        ax=ax,
        cbar_kws={"label": "Within-region percentage"}
    )

    ax.set_title("Motive Composition by Leading Regions")
    ax.tick_params(axis="x", labelrotation=55, labelsize=7)
    ax.tick_params(axis="y", labelsize=7)

    ax = fig.add_subplot(gs[1, 2])

    ax.bar(
        np.arange(len(pareto)),
        pareto["Total"],
        color="#9C755F"
    )

    ax.set_title("Regional Concentration")
    ax.set_xlabel("Regions ranked by total")
    ax.set_ylabel("Cases")
    ax.tick_params(axis="x", labelsize=6)

    ax = fig.add_subplot(gs[2, 0])

    if not rules_df.empty:

        top_rules = rules_df.head(6).copy()

        rule_labels = (
            top_rules["Antecedent"]
            + " → "
            + top_rules["Consequent"]
        ).tolist()

        ax.barh(
            np.arange(len(top_rules)),
            top_rules["Lift_A_to_B"],
            color="#59A14F"
        )

        ax.set_yticks(np.arange(len(top_rules)))
        ax.set_yticklabels(rule_labels, fontsize=6)
        ax.invert_yaxis()

        ax.set_title("Association Rules: Highest Lift")
        ax.set_xlabel("Lift")

    else:

        ax.text(
            0.1, 0.5,
            "No pairs met minimum support",
            transform=ax.transAxes
        )

        ax.set_title("Association Rules")

    ax = fig.add_subplot(gs[2, 1])

    ax.plot(
        np.arange(1, len(cumulative) + 1),
        cumulative,
        marker="o",
        color="#B279A2"
    )

    ax.axhline(90, linestyle="--", color="gray")

    ax.set_title("PCA Cumulative Variance")
    ax.set_xlabel("Components")
    ax.set_ylabel("% Variance")
    ax.set_ylim(0, 105)

    ax = fig.add_subplot(gs[2, 2])

    if (
        not model_results.empty
        and model_results["Accuracy"].notna().any()
    ):

        class_results = model_results[
            model_results["Accuracy"].notna()
        ].sort_values("F1").tail(6)

        ax.barh(
            class_results["Model"],
            class_results["F1"],
            color="#E15759"
        )

        ax.set_xlim(0, 1)
        ax.set_title("Classification F1: Exploratory")
        ax.tick_params(axis="y", labelsize=6)

    else:

        ax.text(
            0.05, 0.5,
            "Not enough rows for classification",
            transform=ax.transAxes
        )

        ax.set_title("Classification Summary")

    dashboard_path = os.path.join(
        out_dir,
        "NCRB_2021_Professional_Dashboard.png"
    )

    fig.savefig(
        dashboard_path,
        dpi=220,
        bbox_inches="tight"
    )

    # ==================================================
    # 14. PROJECT REPORT
    # ==================================================

    report_path = os.path.join(
        out_dir,
        "README_project_results.txt"
    )

    with open(report_path, "w", encoding="utf-8") as f:

        f.write("NCRB 2021 Crime Motive Analytics\n")
        f.write("=" * 45 + "\n")

        f.write(f"Regions analysed: {len(data)}\n")
        f.write(f"Total recorded cases: {total_cases:,.0f}\n")
        f.write(f"Top motive: {motive_table.iloc[0]['Motive']}\n")
        f.write(f"Top region: {state_table.iloc[0]['State/UT']}\n")

        f.write("\nMethods represented:\n")

        methods = [
            "Data cleaning and EDA",
            "Motive distribution analysis",
            "State/UT comparison",
            "Heatmap and correlation analysis",
            "Pareto concentration analysis",
            "Linear regression",
            "Random Forest regression",
            "Classification algorithms",
            "K-Means clustering",
            "Hierarchical clustering",
            "PCA dimensionality reduction",
            "Association rule mining"
        ]

        for method in methods:
            f.write("- " + method + "\n")

        f.write(
            "\nCaution: This is a one-year aggregate dataset. "
            "The models are educational demonstrations, "
            "not reliable crime forecasts. Total is derived "
            "from motive counts, and the classification "
            "label is derived from Total. Counts are not "
            "population-adjusted crime rates.\n"
        )

    # ==================================================
    # 15. FINAL OUTPUT
    # ==================================================

    print("\n" + "=" * 65)
    print("PROJECT FINISHED SUCCESSFULLY")
    print("=" * 65)

    print("\nOutput folder:")
    print(out_dir)

    print("\nDashboard:")
    print(dashboard_path)

    print("\nProject report:")
    print(report_path)

    print("\nAll charts and model results saved.")

    print("\nDisplaying generated plots...")

    plt.show()


# ==================================================
# EXECUTION CONTROL
# ==================================================

if __name__ == "__main__":
    main()
